#!/usr/bin/env bash
# The one command:  ./run.sh <input_dir> <output.json>
# Reads LLM_BASE_URL, LLM_API_KEY, LLM_MODEL from environment or .env
set -euo pipefail

if [ "$#" -ne 2 ]; then
  echo "usage: ./run.sh <input_dir> <output.json>" >&2
  exit 2
fi

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
IN="$(cd "$1" && pwd)"
mkdir -p "$(dirname "$2")"
OUT="$(cd "$(dirname "$2")" && pwd)/$(basename "$2")"
cd "$ROOT"

if command -v python3 >/dev/null 2>&1; then
  PY=python3
else
  PY=python
fi

exec "$PY" solution.py "$IN" "$OUT"
