"""Build output.json in the OFFICIAL schema (schema.json). Only schema properties are emitted. Guarantees:
every chat is tied to exactly one existing person or organisation; people/owners/ids exist in the input; help only on open loops."""
import datetime as dt
from collections import Counter, defaultdict

from .context import clip

VALID_ORG_TYPES = {"company", "residence", "vacation home", "workspace", "society", "school", "other"}
VALID_ORG_ROLES = {"owner", "partner", "helper", "resident", "parent", "member", "other"}
VALID_AREAS = {"self", "spouse", "kids", "parents", "work", "friends", "experiences", "finances", "health", "home"}
VALID_GOAL_TYPES = {"habit", "milestone", "experience"}
VALID_HORIZONS = {"3mo", "1yr", "3yr", "5yr"}


def _person_ids(ctx):
    ids = set()
    for c in ctx.chats.values():
        if c.get("declared", True):
            ids.update(c["members"])
    ids.discard(ctx.self_id)
    ids.discard("")
    return ids


def _fallback_person(ctx, cid, persons):
    """A chat nobody classified still has to be tied: the most active member who is a known person."""
    c = ctx.chats[cid]
    cnt = Counter(m["sender"] for m in ctx.by_chat.get(cid, []) if m["sender"] in persons)
    if cnt:
        return cnt.most_common(1)[0][0]
    mem = [m for m in c["members"] if m in persons]
    return mem[0] if mem else None


def _date(v):
    if isinstance(v, str) and len(v) >= 10:
        try:
            dt.date.fromisoformat(v[:10])
            return v[:10]
        except ValueError:
            return None
    return None


def build(model, ctx):
    persons = _person_ids(ctx)
    org_ids = {o["id"] for o in model["orgs"]}
    links = defaultdict(list)
    for l in model["links"]:
        links[l["person_id"]].append({"organisation": l["org_id"], "link": l["link"]})
    people = []
    seen = set()
    for p in model["people"]:
        if p["id"] not in persons or p["id"] in seen:
            continue
        seen.add(p["id"])
        e = {"id": p["id"], "circle": p["circle"]}
        if links.get(p["id"]):
            e["links"] = [x for x in links[p["id"]] if x["organisation"] in org_ids]
        la = [x for x in p.get("looks_after", []) if x in persons and x != p["id"]]
        if la:
            e["looks_after"] = la
        if not e.get("links"):
            e.pop("links", None)
        people.append(e)
    for pid in sorted(persons - seen):  # silent participants: conservative default
        people.append({"id": pid, "circle": "friend"})

    orgs = []
    for o in model["orgs"]:
        otype = o["type"] if o.get("type") in VALID_ORG_TYPES else "other"
        side = o["side"] if o.get("side") in ("home", "work") else ("home" if otype in ("residence", "vacation home") else "work")
        role = o["role"] if o.get("role") in VALID_ORG_ROLES else "other"
        orgs.append({"id": o["id"], "name": o["name"], "type": otype, "side": side, "role": role})

    owner = {c["chat_id"]: c for c in model["chats"]}
    org_people = defaultdict(set)
    for l in model["links"]:
        org_people[l["org_id"]].add(l["person_id"])
    for oc in model["chats"]:
        if oc["owner_type"] == "org" and oc["chat_id"] in ctx.chats:
            org_people[oc["owner_id"]].update(ctx.chats[oc["chat_id"]]["members"])
    chats = []
    for cid, c in ctx.chats.items():
        if not c.get("declared", True):
            continue
        o = owner.get(cid)
        if o and o["owner_type"] == "org" and o["owner_id"] in org_ids:
            chats.append({"chat_id": cid, "organisation": o["owner_id"]})
        elif o and o["owner_type"] == "person" and o["owner_id"] in persons:
            chats.append({"chat_id": cid, "person": o["owner_id"]})
        elif c["group"] and model["orgs"]:
            mem = set(c["members"]) - {ctx.self_id}
            best = max(model["orgs"], key=lambda g: (len(mem & org_people[g["id"]]), g.get("source") == "seed"))
            chats.append({"chat_id": cid, "organisation": best["id"]})
        else:
            fb = _fallback_person(ctx, cid, persons)
            if fb:
                chats.append({"chat_id": cid, "person": fb})
    declared = {c["chat_id"] for c in chats}

    goals = []
    for g in model["goals"]:
        ev = [e for e in g.get("evidence", []) if e in ctx.by_id]
        if not ev or not g.get("text"):
            continue
        area = g["area"] if g.get("area") in VALID_AREAS else "self"
        gtype = g["type"] if g.get("type") in VALID_GOAL_TYPES else "milestone"
        hz = g["horizon"] if g.get("horizon") in VALID_HORIZONS else "1yr"
        goals.append({"title": g["text"][:100], "area": area, "type": gtype, "horizon": hz, "evidence": ev})
        if len(goals) >= 10:
            break

    loops = []
    for l in model["loops"]:
        if l["chat_id"] not in declared or not (l["owner"] == ctx.self_id or l["owner"] in persons):
            continue
        cb = l.get("resolution_message_id") if l["status"] != "open" else None
        if cb and cb not in ctx.by_id:
            cb = None
        e = {"title": l["title"][:120], "type": l["type"], "owner": "ME" if l["owner"] == ctx.self_id else l["owner"],
             "chat_id": l["chat_id"], "source_msg": l["message_id"], "due": _date(l.get("due")), "status": l["status"],
             "closed_by": cb}
        if l["status"] == "open":
            act = l.get("action") or "leave"
            h = {"action": act}
            if act == "assist":
                h["next_step"] = l.get("next_step") or "Follow up on this item."
                h["needs_yes"] = bool(l.get("needs_approval", True))
            elif act == "remind":
                h["remind_at"] = l.get("remind_at") or "2026-10-01T09:00:00+05:30"
            else:
                h["reason"] = l.get("reason") or "Not Arjun's to chase."
            e["help"] = h
        loops.append(e)
    return {"people": people, "organisations": orgs, "chats": chats, "goals": goals, "open_loops": loops}
