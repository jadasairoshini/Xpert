"""Seed reader. Official layout: {"circles": {person_id: circle}, "organisations": [names], "goals": [...]}.
Falls back to a recursive scan for other layouts."""
from .preprocessing import pick


def _walk(o):
    if isinstance(o, dict):
        yield o
        for v in o.values():
            yield from _walk(v)
    elif isinstance(o, list):
        for v in o:
            yield from _walk(v)


def parse_seed(seed):
    seed = seed if isinstance(seed, dict) else {}
    people, orgs = {}, []
    if isinstance(seed.get("circles"), dict):
        people = {str(k): {"circle": v, "name": None} for k, v in seed["circles"].items() if v}
    for o in seed.get("organisations") or []:
        if isinstance(o, str):
            orgs.append({"name": o, "type": None, "side": None, "role": None})
        elif isinstance(o, dict) and pick(o, ("name", "title")):
            orgs.append({"name": pick(o, ("name", "title")), "type": o.get("type"), "side": o.get("side"), "role": o.get("role")})
    if not people:
        for d in _walk(seed):
            pid = pick(d, ("id", "sender_id", "person_id"))
            if pid is not None and "circle" in d:
                people[str(pid)] = {"circle": d["circle"], "name": pick(d, ("name",))}
    return {"self_id": None, "people": people, "orgs": orgs, "goals": seed.get("goals") or []}
