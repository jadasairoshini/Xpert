"""Tolerant loaders. Field names are NOT assumed here; schema-specific code is added after inspecting schema.json."""
import json
import os
import sys
from collections import Counter


def read_jsonl(path, id_field=None):
    """Return (records, problems). Bad lines are reported, not silently dropped."""
    if not os.path.exists(path):
        raise FileNotFoundError("Missing input file: " + path)
    records, problems, seen = [], [], set()
    with open(path, encoding="utf-8") as f:
        for n, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
            except ValueError as e:
                problems.append("line %d: invalid JSON (%s)" % (n, e))
                continue
            if not isinstance(obj, dict):
                problems.append("line %d: not an object" % n)
                continue
            if id_field:
                i = obj.get(id_field)
                if i is None:
                    problems.append("line %d: missing %s" % (n, id_field))
                    continue
                if i in seen:
                    problems.append("line %d: duplicate %s=%r" % (n, id_field, i))
                    continue
                seen.add(i)
            records.append(obj)
    if not records:
        problems.append("%s contains no usable records" % os.path.basename(path))
    return records, problems


def read_json(path):
    if not os.path.exists(path):
        raise FileNotFoundError("Missing input file: " + path)
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def profile(records):
    """Field-frequency summary, used for the pre-implementation technical analysis."""
    c = Counter()
    for r in records:
        c.update(r.keys())
    return {"count": len(records), "fields": dict(c.most_common())}


if __name__ == "__main__":
    for name in ("chats.jsonl", "messages.jsonl"):
        try:
            recs, probs = read_jsonl(os.path.join(sys.argv[1], name))
            print(name, json.dumps(profile(recs)))
            for pr in probs[:5]:
                print("  problem:", pr)
        except FileNotFoundError as e:
            print(e)
