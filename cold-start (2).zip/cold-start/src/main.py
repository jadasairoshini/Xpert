"""Entry point: python -m src.main <input_folder> <output_path>"""
import json
import os
import sys
import time

from . import (assistance_decider, chat_classifier, goal_extractor, loop_tracker, open_loop_detector,
               organisation_analyzer, output_builder, people_analyzer, schema_utils, validator)
from .config import Config, load_dotenv
from .context import Ctx
from .data_loader import read_json, read_jsonl
from .llm_client import LLMClient
from .preprocessing import identify_self, normalise_chats, normalise_messages
from .seed import parse_seed

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def find_file(input_dir, name, env=None):
    cands = [os.environ.get(env, "")] if env else []
    cands += [os.path.join(input_dir, name), os.path.join(os.path.dirname(input_dir), name), os.path.join(ROOT, name)]
    return next((c for c in cands if c and os.path.exists(c)), None)


def run(input_dir, output_path, mock_responder=None):
    t0 = time.time()
    load_dotenv(os.path.join(ROOT, ".env"))
    cfg = Config.from_env()
    cfg.cache_dir = os.path.join(ROOT, ".cache")
    from .heuristic_llm import responder as heuristic
    if os.environ.get("LLM_BACKEND", "").strip().lower() == "heuristic":
        cfg.mock, mock_responder = True, mock_responder or heuristic
        print("[warn] offline heuristic backend in use (no LLM)", file=sys.stderr)
    cfg.validate()
    raw_chats, p1 = read_jsonl(os.path.join(input_dir, "chats.jsonl"))
    raw_msgs, p2 = read_jsonl(os.path.join(input_dir, "messages.jsonl"))
    for p in (p1 + p2)[:20]:
        print("[input] " + p, file=sys.stderr)
    if not raw_msgs:
        raise ValueError("no usable messages")
    seed_path = find_file(input_dir, "seed.json")
    seed = parse_seed(read_json(seed_path)) if seed_path else {"self_id": None, "people": {}, "orgs": []}
    schema_path = find_file(input_dir, "schema.json", "XPERT_SCHEMA")
    schema = schema_utils.load_schema(schema_path) if schema_path else None
    if not schema:
        print("[warn] schema.json not found: output uses internal field names and is NOT schema-validated", file=sys.stderr)

    msgs = normalise_messages(raw_msgs)
    chats = normalise_chats(raw_chats, msgs)
    self_id = "ME" if any("ME" in c["members"] for c in chats.values()) else identify_self(msgs, seed.get("self_id"))
    llm = LLMClient(cfg, mock_responder=mock_responder, fallback_responder=heuristic)
    ctx = Ctx(msgs, chats, seed, self_id, llm, None)
    print("[input] chats=%d messages=%d self=%s" % (len(chats), len(msgs), self_id), file=sys.stderr)

    def stage(name):
        print("[stage] %s (%.0fs elapsed)" % (name, time.time() - t0), file=sys.stderr, flush=True)

    stage("people")
    people = people_analyzer.run(ctx)
    stage("organisations")
    orgs, links = organisation_analyzer.run(ctx, people)
    stage("chats")
    chat_map = chat_classifier.run(ctx, people, orgs, links)
    stage("goals")
    goals = goal_extractor.run(ctx)
    stage("open loops")
    loops = open_loop_detector.run(ctx)
    stage("loop status")
    loops = loop_tracker.run(ctx, loops)
    stage("where to help")
    loops = assistance_decider.run(ctx, loops)
    for o in orgs:
        o["people"] = [l["person_id"] for l in links if l["org_id"] == o["id"]]
        o["chats"] = [c["chat_id"] for c in chat_map if c["owner_type"] == "org" and c["owner_id"] == o["id"]]
    model = {"people": people, "orgs": orgs, "links": links, "chats": chat_map, "goals": goals, "loops": loops}

    problems = validator.check(model, ctx)
    out = output_builder.build(model, ctx)
    problems += ["schema: " + e for e in schema_utils.validate(schema, out)] if schema else []
    os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)
    usage = llm.usage(len(msgs))
    usage["seconds"] = round(time.time() - t0, 1)
    os.makedirs(os.path.join(ROOT, "ai-logs"), exist_ok=True)
    with open(os.path.join(ROOT, "ai-logs", "usage_report.json"), "w", encoding="utf-8") as f:
        json.dump(usage, f, indent=2)
    print("[usage] " + json.dumps(usage), file=sys.stderr)
    for p in problems[:30]:
        print("[problem] " + p, file=sys.stderr)
    if llm.disabled:
        print("[WARNING] The LLM became unavailable (rate limit/quota). output.json was written but later steps used conservative "
              "fallbacks. Re-run later: finished calls are cached, so it resumes where it stopped.", file=sys.stderr)
    return 3 if problems else 0


def main(argv=None):
    argv = argv or sys.argv
    if len(argv) != 3:
        print("usage: run.sh <input_folder> <output_path>", file=sys.stderr)
        return 2
    try:
        return run(argv[1], argv[2])
    except (FileNotFoundError, RuntimeError, ValueError) as e:
        print("error: %s" % e, file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
