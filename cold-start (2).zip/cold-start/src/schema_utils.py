"""Runtime schema handling: ref resolution, a small JSON-Schema validator, enum lookup."""
import json


def load_schema(path):
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def resolve(schema, node):
    seen = 0
    while isinstance(node, dict) and "$ref" in node and seen < 20:
        cur = schema
        for part in node["$ref"].lstrip("#/").split("/"):
            cur = cur[part.replace("~1", "/").replace("~0", "~")]
        node, seen = cur, seen + 1
    return node


def item_schema(schema, node):
    """Resolve to the object schema of an array's items (or the node itself)."""
    node = resolve(schema, node)
    if isinstance(node, dict) and node.get("type") == "array":
        node = resolve(schema, node.get("items", {}))
    return node if isinstance(node, dict) else {}


def _type_ok(t, v):
    return {"string": isinstance(v, str), "object": isinstance(v, dict), "array": isinstance(v, list),
            "boolean": isinstance(v, bool), "null": v is None,
            "integer": isinstance(v, int) and not isinstance(v, bool),
            "number": isinstance(v, (int, float)) and not isinstance(v, bool)}.get(t, True)


def validate(schema, data, node=None, path="$"):
    """Return a list of error strings (empty = valid). Covers the common keywords."""
    node = resolve(schema, schema if node is None else node)
    if not isinstance(node, dict):
        return []
    errs = []
    for key in ("anyOf", "oneOf"):
        if key in node:
            if not any(not validate(schema, data, s, path) for s in node[key]):
                errs.append("%s: matches none of %s" % (path, key))
            return errs
    t = node.get("type")
    if t:
        ts = t if isinstance(t, list) else [t]
        if not any(_type_ok(x, data) for x in ts):
            return ["%s: expected %s, got %s" % (path, t, type(data).__name__)]
    if "enum" in node and data not in node["enum"]:
        errs.append("%s: %r not in enum %s" % (path, data, node["enum"]))
    if isinstance(data, dict):
        for r in node.get("required", []):
            if r not in data:
                errs.append("%s: missing required '%s'" % (path, r))
        props = node.get("properties", {})
        for k, v in data.items():
            if k in props:
                errs += validate(schema, v, props[k], path + "." + k)
            elif node.get("additionalProperties") is False:
                errs.append("%s: unexpected property '%s'" % (path, k))
    if isinstance(data, list):
        if "maxItems" in node and len(data) > node["maxItems"]:
            errs.append("%s: more than %d items" % (path, node["maxItems"]))
        if "items" in node:
            for i, v in enumerate(data):
                errs += validate(schema, v, node["items"], "%s[%d]" % (path, i))
    return errs


def find_enum(schema, node, name_hints):
    """Find the enum list for a property whose name contains one of the hints."""
    props = item_schema(schema, node).get("properties", {})
    for k, v in props.items():
        if any(h in k.lower() for h in name_hints):
            v = resolve(schema, v)
            if isinstance(v, dict):
                if "enum" in v:
                    return v["enum"]
                for s in v.get("anyOf", []) + v.get("oneOf", []):
                    s = resolve(schema, s)
                    if isinstance(s, dict) and "enum" in s:
                        return s["enum"]
    return None
