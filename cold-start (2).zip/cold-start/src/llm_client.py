"""OpenAI-compatible chat client: timeouts, retries, JSON repair, usage/cost tracking, disk cache."""
import hashlib
import json
import os
import re
import sys
import threading
import time
import urllib.error
import urllib.request


class LLMError(Exception):
    pass


def _retry_delay(body, header):
    """Seconds the server asks us to wait (Retry-After header, or Google's 'retry in 12s' / retryDelay text)."""
    if header and str(header).strip().isdigit():
        return float(header)
    m = re.search(r"retry(?:Delay)?\D{0,12}?(\d+(?:\.\d+)?)\s*s", body or "", re.I)
    return float(m.group(1)) if m else None


def _quota_exhausted(body):
    b = (body or "").lower()
    return "perday" in b.replace(" ", "").replace("_", "") or "limit: 0" in b or "billing" in b and "quota" in b


def extract_json(text):
    """Parse JSON from a model reply, repairing common problems (fences, prose, trailing commas)."""
    if text is None:
        raise ValueError("empty response")
    s = text.strip()
    s = re.sub(r"^```(?:json)?\s*|\s*```$", "", s, flags=re.I)
    try:
        return json.loads(s)
    except ValueError:
        pass
    starts = [i for i in (s.find("{"), s.find("[")) if i != -1]
    if not starts:
        raise ValueError("no JSON found")
    start = min(starts)
    close = "}" if s[start] == "{" else "]"
    end = s.rfind(close)
    if end <= start:
        raise ValueError("unterminated JSON")
    cand = re.sub(r",\s*([}\]])", r"\1", s[start:end + 1])
    return json.loads(cand)


class _ListAsDict(dict):
    """The model sometimes answers with a bare JSON list instead of {"key": [...]}. Every caller reads res.get("<key>", []),
    so a bare list answers for whatever key is asked."""
    def __init__(self, items):
        super().__init__()
        self.items_list = items

    def get(self, key, default=None):
        return self.items_list


def normalise_reply(parsed):
    if isinstance(parsed, list):
        if len(parsed) == 1 and isinstance(parsed[0], dict) and not any(k in parsed[0] for k in ("id", "title", "chat_id", "text")):
            return parsed[0]
        return _ListAsDict(parsed)
    return parsed if isinstance(parsed, dict) else {}


class LLMClient:
    def __init__(self, config, mock_responder=None, fallback_responder=None, use_cache=True):
        self.cfg = config
        self.mock_responder = mock_responder
        self.fallback_responder = fallback_responder
        self.use_cache = use_cache and not config.mock
        self._lock = threading.Lock()
        self._next_slot = 0.0
        self.by_task = {}
        self._cool_until = 0.0
        self._fails = 0
        self.disabled = False
        self._t_start = time.time()
        self._deadline_s = float(os.environ.get("XPERT_DEADLINE_S", "1560") or 1560)  # stop calling the model after 26 min
        self.done_calls = 0
        self.usage_log = os.environ.get("XPERT_USAGE_LOG", "usage.jsonl")
        self.calls = 0
        self.cache_hits = 0
        self.errors = 0
        self.input_tokens = 0
        self.output_tokens = 0
        self.est_in = 0   # rough chars/4 estimate, recorded only in mock/heuristic mode
        self.est_out = 0
        if self.use_cache:
            os.makedirs(config.cache_dir, exist_ok=True)

    def usage(self, n_messages=None):
        total = self.input_tokens + self.output_tokens
        cost = None
        if self.cfg.price_in_per_m is not None and self.cfg.price_out_per_m is not None:
            cost = (self.input_tokens * self.cfg.price_in_per_m
                    + self.output_tokens * self.cfg.price_out_per_m) / 1e6
        rep = {"by_task": {k: {"calls": v[0], "input": v[1], "output": v[2]} for k, v in sorted(self.by_task.items())}, "api_calls": self.calls, "cache_hits": self.cache_hits, "errors": self.errors,
               "input_tokens": self.input_tokens, "output_tokens": self.output_tokens,
               "total_tokens": total, "estimated_cost_usd": cost, "mock": self.cfg.mock}
        if self.cfg.mock:
            rep["ESTIMATED_input_tokens_if_real_llm"] = self.est_in
            rep["ESTIMATED_output_tokens_if_real_llm"] = self.est_out
            if n_messages:
                rep["ESTIMATED_input_tokens_per_1000_msgs"] = round(self.est_in / n_messages * 1000)
        if cost is not None and n_messages:
            rep["cost_per_1000_messages_usd"] = cost / n_messages * 1000
        return rep

    def _log(self, msg):
        # Never log keys or message content.
        print("[llm] " + msg, file=sys.stderr)

    def _key(self, messages, max_tokens):
        raw = json.dumps([self.cfg.model, messages, max_tokens], sort_keys=True, ensure_ascii=False)
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()

    def _throttle(self):
        """Client-side requests-per-minute cap (XPERT_MAX_RPM) so free tiers are not hammered into 429s."""
        with self._lock:
            now = time.time()
            wait = max(0.0, self._cool_until - now)       # shared cooldown after a 429: all workers pause together
            if self.cfg.max_rpm:
                slot = max(now + wait, self._next_slot)
                wait = slot - now
                self._next_slot = slot + 60.0 / self.cfg.max_rpm
        if wait > 0:
            time.sleep(wait)

    def _post(self, payload):
        self._throttle()
        req = urllib.request.Request(
            self.cfg.base_url + "/chat/completions",
            data=json.dumps(payload).encode("utf-8"),
            headers={
                "Content-Type": "application/json",
                "Authorization": "Bearer " + self.cfg.api_key,
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/131.0.0.0 Safari/537.36",
                "Accept": "application/json"
            }
        )
        with urllib.request.urlopen(req, timeout=self.cfg.timeout) as r:
            return json.loads(r.read().decode("utf-8"))

    def _chat_raw(self, messages, max_tokens, json_mode):
        payload = {"model": self.cfg.model, "messages": messages,
                   "max_tokens": max_tokens, "temperature": 0}
        if json_mode:
            payload["response_format"] = {"type": "json_object"}
        if self.cfg.extra_body:
            payload.update(self.cfg.extra_body)
        last, wait = None, 1
        for attempt in range(self.cfg.max_retries + 1):
            try:
                try:
                    data = self._post(payload)
                except urllib.error.HTTPError as e:
                    if e.code == 400 and ("response_format" in payload or self.cfg.extra_body):
                        payload.pop("response_format", None)  # endpoint rejected optional fields: retry plain
                        for k in (self.cfg.extra_body or {}):
                            payload.pop(k, None)
                        self._log("HTTP 400: retrying without optional request fields")
                        data = self._post(payload)
                    else:
                        raise
                u = data.get("usage") or {}
                pt, ct = int(u.get("prompt_tokens") or 0), int(u.get("completion_tokens") or 0)
                task = str(messages[0]["content"]).split()[0] if messages else "?"
                with self._lock:
                    self.calls += 1
                    self.input_tokens += pt
                    self.output_tokens += ct
                    t = self.by_task.setdefault(task, [0, 0, 0])
                    t[0] += 1; t[1] += pt; t[2] += ct
                    try:  # same format as the starter kit's llm.py
                        with open(self.usage_log, "a", encoding="utf-8") as f:
                            f.write(json.dumps({"model": self.cfg.model, "prompt_tokens": pt, "completion_tokens": ct}) + "\n")
                    except OSError:
                        pass
                return data["choices"][0]["message"]["content"]
            except urllib.error.HTTPError as e:
                try:
                    body = e.read(600).decode("utf-8", "replace")
                except Exception:
                    body = ""
                snippet = " ".join(body.split())[:220]
                last = "HTTP %s %s" % (e.code, snippet)
                if e.code == 429 and _quota_exhausted(body):
                    self.disabled = True
                    raise LLMError("quota exhausted for this key/model (%s). Wait for the quota reset, use a model that has free quota, "
                                   "or enable billing." % snippet)
                if e.code not in (408, 409, 429, 500, 502, 503, 504):
                    break
                wait = _retry_delay(body, e.headers.get("Retry-After") if e.headers else None)
                wait = (wait + 1.0) if wait is not None else min(5.0 * 2 ** attempt, 90.0)
                if e.code == 429:
                    with self._lock:
                        self._cool_until = max(self._cool_until, time.time() + wait)
                    self._log("rate limited (429): pausing all workers ~%ds" % wait)
            except (urllib.error.URLError, TimeoutError, KeyError, ValueError) as e:
                last = type(e).__name__
                wait = 2 ** attempt
            with self._lock:
                self.errors += 1
            self._log("attempt %d failed (%s)" % (attempt + 1, last))
            if attempt < self.cfg.max_retries:
                time.sleep(min(wait, 120))
        raise LLMError("LLM call failed after retries: %s" % last)

    def chat_json(self, system, user, max_tokens=1500, repair_attempts=1):
        """Return parsed JSON from the model. Re-asks once if the reply is malformed."""
        messages = [{"role": "system", "content": system}, {"role": "user", "content": user}]
        if self.cfg.mock:
            if not self.mock_responder:
                raise LLMError("mock mode requires a mock_responder")
            res = self.mock_responder(system, user)
            with self._lock:
                self.calls += 1
                self.est_in += (len(system) + len(user)) // 4
                self.est_out += len(json.dumps(res, ensure_ascii=False)) // 4
                t = self.by_task.setdefault(system.split()[0], [0, 0, 0])
                t[0] += 1; t[1] += (len(system) + len(user)) // 4; t[2] += len(json.dumps(res, ensure_ascii=False)) // 4
            return res
        path = None
        if self.use_cache:
            path = os.path.join(self.cfg.cache_dir, self._key(messages, max_tokens) + ".json")
            if os.path.exists(path):
                with self._lock:
                    self.cache_hits += 1
                with open(path, encoding="utf-8") as f:
                    return normalise_reply(json.load(f))
        if not self.disabled and time.time() - self._t_start > self._deadline_s:
            self.disabled = True
            self._log("time budget reached: LLM calls stopped; remaining steps use conservative fallbacks")
        if self.disabled:
            if self.fallback_responder:
                self._log("LLM disabled; using rule-based fallback")
                return normalise_reply(self.fallback_responder(system, user))
            raise LLMError("LLM disabled after repeated failures or time budget")
        try:
            text = self._chat_raw(messages, max_tokens, json_mode=True)
            for attempt in range(repair_attempts + 1):
                try:
                    parsed = extract_json(text)
                    break
                except ValueError:
                    if attempt == repair_attempts:
                        raise LLMError("model returned malformed JSON")
                    messages += [{"role": "assistant", "content": text[:2000]},
                                 {"role": "user", "content": "Invalid JSON. Reply with only the valid JSON object."}]
                    text = self._chat_raw(messages, max_tokens, json_mode=True)
            with self._lock:
                self._fails = 0
                self.done_calls += 1
                if self.done_calls % 20 == 0:
                    self._log("progress: %d calls completed" % self.done_calls)
            if path:
                with open(path, "w", encoding="utf-8") as f:
                    json.dump(parsed, f, ensure_ascii=False)
            return normalise_reply(parsed)
        except LLMError as e:
            with self._lock:
                self._fails += 1
                if self._fails >= 15:
                    self.disabled = True
                    self._log("too many consecutive failures: LLM calls stopped; remaining steps use conservative fallbacks")
            if self.fallback_responder:
                self._log("LLM call failed (%s); using rule-based fallback" % str(e)[:100])
                return normalise_reply(self.fallback_responder(system, user))
            raise
