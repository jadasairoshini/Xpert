"""Field auto-detection, normalisation, chronological sorting and windowing. No field names are hardcoded
beyond a list of common candidates, so a differently named schema is detected from the data itself."""
import datetime as dt
import re
from collections import defaultdict

CAND = {
    "id": ("id", "message_id", "msg_id"),
    "chat": ("chat_id", "chat", "thread_id", "conversation_id"),
    "sender": ("sender_id", "sender", "from", "author", "from_id"),
    "sender_name": ("sender_name", "from_name", "author_name", "name"),
    "ts": ("timestamp", "ts", "time", "date", "sent_at", "created_at", "datetime"),
    "text": ("text", "body", "message", "content", "caption", "transcript"),
    "quoted": ("quoted_id", "reply_to", "quoted_message_id", "reply_to_id", "in_reply_to"),
    "type": ("type", "kind", "message_type", "msg_type"),
}
CHAT_CAND = {
    "id": ("id", "chat_id"),
    "name": ("name", "title", "subject"),
    "group": ("is_group", "group", "isGroup"),
    "members": ("participants", "members", "member_ids"),
    "type": ("type", "kind"),
}


def pick(d, names, default=None):
    for n in names:
        if n in d and d[n] is not None:
            return d[n]
    return default


def parse_ts(v):
    if v is None:
        return None
    if isinstance(v, (int, float)):
        return float(v) / 1000.0 if v > 1e11 else float(v)
    if isinstance(v, str):
        s = v.strip()
        try:
            return float(s) / 1000.0 if float(s) > 1e11 else float(s)
        except ValueError:
            pass
        try:
            d = dt.datetime.fromisoformat(s.replace("Z", "+00:00"))
            if d.tzinfo is None:
                d = d.replace(tzinfo=dt.timezone.utc)
            return d.timestamp()
        except ValueError:
            return None
    return None


def normalise_messages(raw):
    out, order = [], 0
    for r in raw:
        mid = pick(r, CAND["id"])
        if mid is None:
            continue
        txt = pick(r, CAND["text"], "")
        if not isinstance(txt, str):
            txt = str(txt)
        out.append({"id": str(mid), "chat": str(pick(r, CAND["chat"], "")), "sender": str(pick(r, CAND["sender"], "")),
                    "sender_name": pick(r, CAND["sender_name"]), "ts": parse_ts(pick(r, CAND["ts"])),
                    "text": txt.strip(), "quoted": (str(pick(r, CAND["quoted"])) if pick(r, CAND["quoted"]) is not None else None),
                    "type": pick(r, CAND["type"], "text"), "_o": order})
        order += 1
    # chronological; stable on original order when timestamps are missing/equal
    out.sort(key=lambda m: (m["ts"] if m["ts"] is not None else float("inf"), m["_o"]))
    return out


def normalise_chats(raw, messages):
    chats = {}
    for r in raw:
        cid = pick(r, CHAT_CAND["id"])
        if cid is None:
            continue
        mem = pick(r, CHAT_CAND["members"], [])
        mem = [str(x.get("id") if isinstance(x, dict) else x) for x in mem] if isinstance(mem, list) else []
        g = pick(r, CHAT_CAND["group"])
        if g is None:
            g = str(pick(r, CHAT_CAND["type"], "")).lower() == "group"
        chats[str(cid)] = {"id": str(cid), "name": pick(r, CHAT_CAND["name"], ""), "group": bool(g), "members": mem, "declared": True}
    by_chat = group_by_chat(messages)
    for cid, ms in by_chat.items():
        c = chats.setdefault(cid, {"id": cid, "name": "", "group": False, "members": [], "declared": False})
        senders = {m["sender"] for m in ms}
        if not c["members"]:
            c["members"] = sorted(senders)
        if len(senders | set(c["members"])) > 2:
            c["group"] = True
    return chats


def group_by_chat(messages):
    d = defaultdict(list)
    for m in messages:
        d[m["chat"]].append(m)
    return d


def fmt(m, names=None, maxlen=280):
    who = (names or {}).get(m["sender"]) or m["sender"]
    t = re.sub(r"https?://\S+", "<url>", m["text"]).replace("\n", " ")
    t = t[:maxlen] + "…" if len(t) > maxlen else t
    if not t and m["type"] != "text":
        t = "<%s>" % m["type"]
    q = " >%s" % m["quoted"] if m["quoted"] else ""
    when = ""
    if m["ts"] is not None:
        when = dt.datetime.fromtimestamp(m["ts"], dt.timezone.utc).strftime("%Y-%m-%d %H:%M ")
    return "[%s]%s %s%s: %s" % (m["id"], q, when, who, t)


def windows(msgs, max_chars=7000, overlap=3):
    """Split a chat's chronological messages into compact windows with a small overlap."""
    out, cur, size = [], [], 0
    for m in msgs:
        L = len(m["text"][:280]) + 40
        if cur and size + L > max_chars:
            out.append(cur)
            cur = cur[-overlap:]
            size = sum(len(x["text"][:280]) + 40 for x in cur)
        cur.append(m)
        size += L
    if cur and (not out or len(cur) > overlap):
        out.append(cur)
    return out


def identify_self(messages, seed_hint=None):
    """Arjun = the sender present in the most chats (or the seed's explicit id)."""
    if seed_hint:
        return str(seed_hint)
    if any(m["sender"] == "ME" for m in messages):
        return "ME"  # the brief states Arjun's own id is ME
    chats = defaultdict(set)
    for m in messages:
        chats[m["sender"]].add(m["chat"])
    return max(chats, key=lambda s: len(chats[s])) if chats else ""


def useful(m):
    """Drop pure noise (photo placeholders, emoji-only) from LLM prompts; ids stay valid for everything else."""
    t = m["text"]
    return bool(re.search(r"[^\W\d_]{2}", t)) and not re.fullmatch(r"\[[\w ]+\]", t.strip())
