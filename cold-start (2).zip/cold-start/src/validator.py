"""Referential integrity checks (independent of the schema validator)."""


def check(out_model, ctx):
    errs = []
    pids = {p["id"] for p in out_model["people"]}
    oids = {o["id"] for o in out_model["orgs"]}
    seen = set()
    for p in out_model["people"]:
        if p["id"] in seen:
            errs.append("duplicate person " + p["id"])
        seen.add(p["id"])
    for l in out_model["links"]:
        if l["person_id"] not in pids or l["org_id"] not in oids:
            errs.append("bad link %r" % l)
    for c in out_model["chats"]:
        if c["chat_id"] not in ctx.chats or c["owner_id"] not in (pids | oids):
            errs.append("bad chat owner %r" % c)
    if len(out_model["goals"]) > 10:
        errs.append("more than 10 goals")
    for g in out_model["goals"]:
        errs += ["goal evidence missing id %s" % e for e in g.get("evidence", []) if e not in ctx.by_id]
    for l in out_model["loops"]:
        if l["message_id"] not in ctx.by_id or ctx.by_id[l["message_id"]]["chat"] != l["chat_id"]:
            errs.append("loop %s origin mismatch" % l["id"])
        if l["status"] != "open" and l.get("resolution_message_id") is not None and l["resolution_message_id"] not in ctx.by_id:
            errs.append("loop %s resolved with unknown message id %s" % (l["id"], l.get("resolution_message_id")))
        if l["status"] == "open" and l.get("action") is None:
            errs.append("open loop %s has no action" % l["id"])
    return errs
