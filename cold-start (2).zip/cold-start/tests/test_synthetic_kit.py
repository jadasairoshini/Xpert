"""Generator -> pipeline (offline heuristic backend) -> OFFICIAL check.py. Synthetic data in the official formats."""
import io, json, os, re, subprocess, sys, tempfile, unittest
from contextlib import redirect_stdout

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)


def run(*cmd, **env):
    return subprocess.run([sys.executable, *cmd], cwd=ROOT, env=dict(os.environ, **env), capture_output=True, text=True,
                          encoding="utf-8", errors="replace")


class T(unittest.TestCase):
    def test_official_checker_accepts_output(self):
        from tools import make_synthetic_kit
        with tempfile.TemporaryDirectory() as d:
            with redirect_stdout(io.StringIO()):
                make_synthetic_kit.main(d, 1)
            out = os.path.join(d, "out.json")
            r = run("-m", "src.main", os.path.join(d, "data"), out, LLM_BACKEND="heuristic")
            self.assertEqual(r.returncode, 0, r.stderr[-800:])
            c = run("check.py", os.path.join(d, "data"), out)
            self.assertEqual(c.returncode, 0, c.stdout[-800:])
            self.assertIn("The output is valid.", c.stdout)
            total = float(re.search(r"Total from the data\s+([\d.]+)", c.stdout).group(1))
            self.assertGreater(total, 40)   # sanity floor on synthetic data only; not a quality claim

    def test_real_file_features(self):
        """Empty sender_name, photo placeholders, seed with circles+org names, silent participant, undeclared chat id."""
        with tempfile.TemporaryDirectory() as d:
            w = lambda n, rows: open(os.path.join(d, n), "w", encoding="utf-8").write("".join(json.dumps(r, ensure_ascii=False) + "\n" for r in rows))
            w("chats.jsonl", [{"chat_id": "C1", "name": "x", "is_group": False, "participants": ["ME", "P1"]},
                              {"chat_id": "C2", "name": "grp", "is_group": True, "participants": ["ME", "P1", "P2", "P3"]}])
            M = lambda i, c, s, b, k="text": {"id": i, "chat_id": c, "sender_id": s, "sender_name": "" if s != "ME" else "Arjun", "ts": 1787535000 + int(i[1:]) * 60,
                                              "kind": k, "body": b, "quoted_id": None}
            w("messages.jsonl", [M("M1", "C1", "P1", "[photo]", "image_caption"), M("M2", "C1", "ME", "bhai kal milte hain"),
                                 M("M3", "C2", "P2", "https://example.com/news Wow"), M("M4", "C2", "ME", "ok"), M("M5", "CX", "P1", "stray")])
            with open(os.path.join(d, "seed.json"), "w") as f:
                json.dump({"circles": {"P1": "sibling"}, "organisations": ["Acme"], "goals": []}, f)
            out = os.path.join(d, "o.json")
            r = run("-m", "src.main", d, out, LLM_BACKEND="heuristic")
            self.assertEqual(r.returncode, 0, r.stderr[-800:])
            c = run("check.py", d, out)
            self.assertEqual(c.returncode, 0, c.stdout[-800:])
            data = json.load(open(out, encoding="utf-8"))
            self.assertEqual({p["id"] for p in data["people"]}, {"P1", "P2", "P3"})   # silent P3 included, ME never
            self.assertEqual({x["chat_id"] for x in data["chats"]}, {"C1", "C2"})      # undeclared CX not output


if __name__ == "__main__":
    unittest.main()


class RealDevSmoke(unittest.TestCase):
    """Runs only if data/dev is present (it is never committed). Offline backend: checks shape + crash-freedom on the real files."""
    @unittest.skipUnless(os.path.exists(os.path.join(ROOT, "data", "dev", "messages.jsonl")), "data/dev not present")
    def test_dev_output_is_valid(self):
        with tempfile.TemporaryDirectory() as d:
            out = os.path.join(d, "o.json")
            dev = os.path.join(ROOT, "data", "dev")
            r = run("-m", "src.main", dev, out, LLM_BACKEND="heuristic")
            self.assertEqual(r.returncode, 0, r.stderr[-800:])
            c = run("check.py", dev, out)
            self.assertIn("The output is valid.", c.stdout)
