# Development & Session Log

This log documents the iterative engineering sessions used to develop, debug, and optimize the Cold Start solution.

## Session 1: Pipeline & Architecture Setup
1. Reviewed challenge brief and starter kit specification.
2. Built modular pipeline (`preprocessing`, `seed`, `people_analyzer`, `organisation_analyzer`, `chat_classifier`, `goal_extractor`, `open_loop_detector`, `loop_tracker`, `assistance_decider`, `output_builder`, `validator`).
3. Created an offline test harness with synthetic data and a deterministic rule-based stand-in (`src/heuristic_llm.py`).
4. Designed OpenAI-compatible client (`src/llm_client.py`) with threading concurrency, disk caching (`.cache/`), backoff, and JSON repair.

## Session 2: Schema & Dev Dataset Integration
1. Re-aligned data structures to official `schema.json`.
2. Studied initial dev set characteristics: requests to Arjun dominate loops (~80%), group chats belong to organisations, ~66% of tasks reach resolution.
3. Added group-to-organisation fallback and deterministic heuristics for high-certainty relations.

## Session 3: Deep Debugging, Quality Improvements & Submission Prep
1. **Loop Tracker Windowing Bug Fixed**: In `loop_tracker.py`, all loops in a chat were previously windowed from `first_loop` to `first_loop + 150`. For long chats (e.g. `C10` with 865 messages), any loop occurring after message 150 had its subsequent context completely truncated. Refactored `loop_tracker.py` to cluster loops by positional proximity, ensuring every loop is replayed with full context following its origin.
2. **Windows CRLF Regex Fix**: Fixed multiline regex patterns across the heuristic parser where `\r\n` line endings prevented message ID and loop title matching.
3. **Resilience & Fallback Architecture**: Enhanced `LLMClient` to gracefully fall back to the multilingual rule-based responder when API rate limits or quota exhaustion occurs, rather than failing silently with empty results. Fallback outputs are not cached to disk to preserve clean resumability once API quota resets.
4. **Assistance & Output Compliance**: Fixed `assistance_decider.py` and `output_builder.py` so that every open loop receives a valid, schema-compliant `help` object (`action`, `next_step`, `needs_yes`, `remind_at`, `reason`). Fixed `closed_by` to strictly reference existing message IDs.
5. **Environment & Script Fixes**: Fixed `LLM_BACKEND` string stripping in `main.py` (handling Windows cmd trailing space quirk). Updated `run.sh` to auto-detect `python3` or `python`. Updated `.gitignore` to rigorously exclude `.env`, `.cache`, `out*.json`, and test artifacts. Added clean `.env.example`.
6. **Validation**: Ran complete test suite (14/14 tests passing) and validated against official `check.py` on both `example` and `data/dev` datasets with 0 schema violations.
