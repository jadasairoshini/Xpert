# Cold Start – Xpert Winter Internship 2026

Reads one person's WhatsApp export (`chats.jsonl`, `messages.jsonl`, `seed.json`) and writes `output.json` in the official
`schema.json`: people + circles + org links, organisations, chat ties, goals (<=10), open loops with status and assist/remind/leave.

## Run
First test the connection: `python tools/ping_llm.py` (reads `.env`; prints SUCCESS or the reason it failed).
No third-party dependencies (Python 3.9+, standard library only).
```
cp .env.example .env      # LLM_BASE_URL, LLM_API_KEY, LLM_MODEL (+ optional LLM_PRICE_IN_PER_M / LLM_PRICE_OUT_PER_M, XPERT_WORKERS)
./run.sh data/dev out.json                  # Windows PowerShell: python -m src.main data/dev out.json
python3 check.py data/dev out.json          # official checker (shape + dev score)
```
Exit codes: 0 ok, 1 input/config error, 2 usage, 3 output written with validation problems. Usage → `ai-logs/usage_report.json`.

## Pipeline (src/)
`data_loader` → `preprocessing` (field detection, chronological sort, windows, noise filter) → `seed` → `people_analyzer` →
`organisation_analyzer` → `chat_classifier` → `goal_extractor` → `open_loop_detector` → `loop_tracker` (separate status pass over later
messages) → `assistance_decider` → `validator` → `output_builder` (official schema). LLM calls run in parallel (`XPERT_WORKERS`, default 8)
with retries/backoff, JSON repair and a disk cache (`llm_client`).

## Quick start (Windows PowerShell, one line at a time)
```
copy .env.example .env     # then open .env and paste your key
python tools/ping_llm.py   # connection test
python solution.py data/dev out.json
python check.py data/dev out.json
```
If you see HTTP 429 (rate limit): keep `XPERT_WORKERS=2`, `XPERT_MAX_RPM=8`, `XPERT_LEAN=1` in `.env` (see `.env.example`). The client pauses and retries by itself; finished calls are cached in `.cache/`, so run the same command again to resume. A message saying the quota is exhausted means the key/model has no free quota left: wait for the reset or use a model with free quota.

Linux/macOS: `./run.sh data/dev out.json`. Details of the run are in `ai-logs/usage_report.json` (tokens per stage, cost if prices are set).

## Offline testing (no key, no network)
`python tools/make_synthetic_kit.py <dir> [scale]` writes SYNTHETIC data in the official formats. `LLM_BACKEND=heuristic` uses a rule-based
stand-in for the model (`src/heuristic_llm.py`). Tests: `python -m unittest discover -s tests -t .`
Synthetic scores only prove plumbing; the real data is far messier and needs a real model.

## Status
Tests pass offline (`python -m unittest discover -s tests -t .`, 14 tests). Official `check.py` accepts the output shape. Dev score of the last partial real run is in WRITEUP.md.
`.env` is never committed (see `.env.example`); the scorer supplies LLM_BASE_URL / LLM_API_KEY / LLM_MODEL through the environment.
