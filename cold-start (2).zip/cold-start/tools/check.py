"""Scorer for the SYNTHETIC kit (mirrors the category weights in the brief; not the official checker).
Usage: python tools/check.py <output.json> <answers/key.json> [--last2w]"""
import json
import sys


def f1(tp, fp, fn):
    p = tp / (tp + fp) if tp + fp else 0
    r = tp / (tp + fn) if tp + fn else 0
    return 2 * p * r / (p + r) if p + r else 0


def main(out_path, key_path, last2w=False):
    with open(out_path, encoding="utf-8") as f:
        out = json.load(f)
    with open(key_path, encoding="utf-8") as f:
        key = json.load(f)
    S = {}
    got = {p["id"]: p["circle"] for p in out["people"]}
    S["people(12)"] = 12 * sum(got.get(p) == c for p, c in key["people"].items()) / len(key["people"])
    og = {(o["name"].lower(), o["side"]) for o in out["organisations"]}
    ok = {(o["name"].lower(), o["side"]) for o in key["orgs"]}
    S["orgs(8)"] = 8 * f1(len(og & ok), len(og - ok), len(ok - og))
    oid = {o["id"]: o["name"].lower() for o in out["organisations"]}
    cg = {c["chat_id"]: c["owner_id"] for c in out["chats"]}
    ok_names = {"org_work": "arjun textiles", "org_home": "home", "org_society": "green valley society"}
    right = 0
    for cid, owner in key["chats"].items():
        want = ok_names.get(owner, owner)
        have = oid.get(cg.get(cid), cg.get(cid))
        right += (have == want)
    S["chats(8)"] = 8 * right / len(key["chats"])
    used, tp = set(), 0
    for g in out["goals"]:
        for i, kg in enumerate(key["goals"]):
            if i not in used and set(g["evidence"]) & set(kg["evidence"]):
                used.add(i)
                tp += (g["area"] == kg["area"]) * 0.5 + (g["horizon"] == kg["horizon"]) * 0.25 + (g["type"] == kg["type"]) * 0.25
                break
    S["goals(8)"] = 8 * f1(tp, len(out["goals"]) - len(used), len(key["goals"]) - len(used))
    cutoff = key["last_two_weeks_from"]  # last-two-weeks filter uses the origin message timestamp
    kl = {l["origin"]: l for l in key["loops"]}
    ol = {l["message_id"]: l for l in out["open_loops"]}
    if last2w:
        import os
        mp = os.environ.get("MSGS", "")
        times = {}
        with open(mp, encoding="utf-8") as f:
            for line in f:
                r = json.loads(line)
                times[r["id"]] = r["timestamp"]
        kl = {k: v for k, v in kl.items() if times[k] >= cutoff}
        ol = {k: v for k, v in ol.items() if times.get(k, "") >= cutoff}
    tp = len(set(kl) & set(ol))
    S["loops detect(14)"] = 14 * f1(tp, len(set(ol) - set(kl)), len(set(kl) - set(ol)))
    pts = 0.0
    for k in set(kl) & set(ol):
        a, b = kl[k], ol[k]
        if b["status"] == a["status"]:
            pts += 1
        elif b["status"] == "done" and a["status"] == "open":
            pts -= 1  # marking an open task done is penalised more
    S["loops status(14)"] = 14 * max(0, pts) / max(1, len(kl))
    pts = n = 0
    for k, a in kl.items():
        if a["status"] != "open":
            continue
        n += 1
        b = ol.get(k)
        if not b or b["status"] != "open":
            continue
        if b.get("action") == a["action"]:
            pts += 1
        elif a["action"] == "leave":
            pts -= 1  # wrong assist/remind on a leave task is penalised
    S["where to help(10)"] = 10 * max(0, pts) / max(1, n)
    for k, v in S.items():
        print("%-20s %5.2f" % (k, v))
    print("%-20s %5.2f / 74 (cost 12 not scored here)" % ("TOTAL", sum(S.values())))


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2], "--last2w" in sys.argv)
