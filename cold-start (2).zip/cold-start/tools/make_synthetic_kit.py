"""Generate a SYNTHETIC dev kit in the OFFICIAL Xpert file formats (not real data): data/{chats,messages}.jsonl, seed.json, answers/answers.json.
Multilingual (English / Hinglish / Hindi / Bengali), 8 weeks. Usage: python tools/make_synthetic_kit.py <out_dir> [filler_scale]"""
import datetime as dt
import json
import os
import random
import sys

R = random.Random(7)
ME = "ME"
PEOPLE = {  # id: (name, circle, seeded?)
    "u_priya": ("Priya", "spouse", True), "u_aarav": ("Aarav", "child", True), "u_maa": ("Maa", "parent", True),
    "u_rohit": ("Rohit", "sibling", False), "u_sunita": ("Sunita Aunty", "in-law", False),
    "u_karan": ("Karan", "friend", False), "u_neha": ("Neha", "colleague", False), "u_vikram": ("Vikram", "partner", False),
    "u_mehta": ("Mehta ji", "client", False), "u_supply": ("Gupta Supplies", "vendor", False),
    "u_ramu": ("Ramu", "staff", False), "u_sanjay": ("Sanjay", "staff", False), "u_mausi": ("Mausi", "relative", False),
}
CUES = {  # chatter that reveals the relationship (text only, never the name)
    "sibling": ["bhai mummy ka birthday plan karna hai", "bhaiya, dad's checkup report mil gayi?", "ei dada, kothay tumi"],
    "in-law": ["Beta, Priya ko bol dena dawai le le", "Mummyji ne khana bheja hai aapke liye", "bahu kaisi hai"],
    "friend": ["bro dinner tonight?", "yaar match dekha kal?", "weekend pe trip plan karte hain bro"],
    "colleague": ["team standup at 10 tomorrow", "I updated the sprint board for the team", "team lunch on friday"],
    "partner": ["partner, profit share meeting needed", "our partnership accounts look good, partner", "partner ji, new showroom ka plan"],
    "client": ["our order delivery status for my order?", "my order needs to be urgent, please", "we placed our order last week"],
    "vendor": ["new rate list attached, supply starts monday", "supply of fabric will arrive soon", "rate list updated for the supply"],
    "staff": ["sir ji aaj chhutti chahiye", "madam ji groceries aa gaye", "sir ji gaadi service ke liye gayi hai"],
    "relative": ["Mausi here, all fine at the village", "family function me aana zaroor", "chacha ji ki tabiyat theek hai"],
    "spouse": ["dinner mein kya banega", "Aarav ke school se call aaya tha", "love you, aaj late aaunga"],
    "child": ["papa homework help karo", "papa kal match hai", "papa ice cream?"],
    "parent": ["beta khana kha liya?", "beta dawai le li?", "beta kab aaoge ghar"],
}
LANG = {
    "commit": ["I will send the {t} to you by {d}", "Main {t} bhej dunga {d} tak", "मैं {t} {d} तक भेज दूंगा", "আমি {t} পাঠিয়ে দেব {d} এর মধ্যে"],
    "done": ["{T} sent, please check", "{t} bhej diya, check kar lena", "{t} भेज दिया है", "{t} পাঠিয়ে দিয়েছি"],
    "other": ["I will send the {t} tomorrow", "Main {t} kal bhej dungi", "मैं {t} कल भेज दूंगी", "আমি {t} কাল পাঠিয়ে দেব"],
    "other_done": ["{T} sent", "{t} bhej diya", "{t} भेज दिया", "{t} পাঠিয়ে দিয়েছি"],
    "ack": ["ok thanks", "theek hai ji", "ठीक है", "ঠিক আছে"],
    "cancel": ["Cancel the {t} meeting, no need now", "{t} meeting cancel kar do, ab zarurat nahi", "{t} meeting cancel कर दो, अब ज़रूरत नहीं", "{t} meeting cancel করে দাও, দরকার নেই"],
}
DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]
THINGS = ["quotation", "invoice", "report", "proposal", "samples", "catalogue", "estimate", "agreement"]
GOALS = [
    ("I want to run a half marathon this year", "health", "milestone", "1yr"),
    ("Planning a Goa family trip next year, saving for it", "experiences", "experience", "1yr"),
    ("Want to open a second showroom in 3 years", "work", "milestone", "3yr"),
    ("Need to build a 6 month emergency fund this year", "finances", "milestone", "1yr"),
    ("Main roz subah walk karunga, habit banani hai", "health", "habit", "3mo"),
]
FILL = ["ok", "hmm", "good morning", "kya haal hai", "see you", "😂", "thik ache", "haan ji", "call later", "noted", "thanks yaar"]


def main(out, scale=1):
    os.makedirs(os.path.join(out, "data"), exist_ok=True)
    os.makedirs(os.path.join(out, "answers"), exist_ok=True)
    chats = {}
    for pid, (n, c, _) in PEOPLE.items():
        chats["c_" + pid] = {"name": n, "group": False, "members": [ME, pid]}
    groups = {
        "c_team": ("Textiles Team", ["u_neha", "u_vikram", "u_supply"], "org_work"),
        "c_staff": ("Home Staff", ["u_ramu", "u_sanjay", "u_priya"], "org_home"),
        "c_society": ("Green Valley Residents", ["u_karan", "u_mehta"], "org_society"),
        "c_school": ("Class 4B Parents", ["u_priya", "u_karan"], "u_aarav"),
        "c_friends": ("College Friends", ["u_karan", "u_rohit"], "u_karan"),
    }
    for cid, (n, mem, _) in groups.items():
        chats[cid] = {"name": n, "group": True, "members": [ME] + mem}
    ev = []  # (day, hour, chat, sender, text, key, quoted_key)

    def add(day, hour, chat, sender, text, key=None, quoted=None):
        ev.append((day, hour + R.random() * 0.5, chat, sender, text, key, quoted))
        return key

    # relationship chatter + filler
    for pid, (n, c, _) in PEOPLE.items():
        for k in range(8 * scale):
            add(R.randint(0, 55), R.randint(8, 21), "c_" + pid, pid, R.choice(CUES[c]))
            add(R.randint(0, 55), R.randint(8, 21), "c_" + pid, ME, R.choice(FILL))
    gcues = {"c_team": CUES["colleague"] + CUES["vendor"], "c_staff": CUES["staff"] + ["gaadi service kal hai", "sir ji sabzi le aaye"],
             "c_society": ["Society maintenance bill pending, committee meeting soon", "lift repair in the society tomorrow"],
             "c_school": ["School PTA meeting on Saturday, Class 4B", "homework for Class 4B uploaded", "PTA fees reminder for school"],
             "c_friends": CUES["friend"]}
    for cid, (n, mem, _) in groups.items():
        for k in range(14 * scale):
            s = R.choice(mem)
            add(R.randint(0, 55), R.randint(8, 21), cid, s, R.choice(gcues[cid]) if R.random() < 0.6 else R.choice(FILL))
    add(3, 10, "c_society", "u_karan", "Society maintenance due this month, committee meeting sunday")
    add(5, 10, "c_school", "u_priya", "School PTA meeting reminder for Class 4B")
    # goals
    gkeys = {}
    for gi, (t, a, ty, h) in enumerate(GOALS):
        for rep in range(3):
            chat = R.choice(["c_u_karan", "c_u_priya", "c_u_rohit", "c_friends"])
            k = "g%d_%d" % (gi, rep)
            add(R.randint(0, 55), R.randint(8, 21), chat, ME, t, key=k)
            gkeys.setdefault(gi, []).append(k)
    # loops
    loops = []
    people_ids = [p for p in PEOPLE if PEOPLE[p][1] in ("client", "vendor", "colleague", "partner", "friend", "sibling")]
    for i in range(46):
        kind = ["commit", "other", "cancel", "staff", "question", "deadline"][i % 6]
        day = R.randint(0, 53) if i > 8 else R.randint(44, 53)
        t = R.choice(THINGS)
        lang = R.randrange(4)
        outcome = R.choice(["done", "done", "open", "open"]) if kind != "cancel" else R.choice(["dropped", "dropped", "open"])
        x = R.choice(people_ids)
        chat = "c_" + x
        lk = "L%d" % i
        rk = "R%d" % i
        if kind == "commit":
            add(day, 11, chat, ME, LANG["commit"][lang].format(t=t, d=R.choice(DAYS)), key=lk)
            if outcome == "done":
                add(day + R.randint(1, 3), 15, chat, ME, LANG["done"][lang].format(t=t, T=t.capitalize()), key=rk)
            else:
                add(day, 12, chat, x, LANG["ack"][lang])
            row = dict(type="commitment", owner=ME, chat=chat, origin=lk)
        elif kind == "other":
            add(day, 11, chat, x, LANG["other"][lang].format(t=t), key=lk)
            add(day, 12, chat, ME, LANG["ack"][lang])
            if outcome == "done":
                add(day + R.randint(1, 3), 16, chat, x, LANG["other_done"][lang].format(t=t, T=t.capitalize()), key=rk)
            row = dict(type="followup", owner=x, chat=chat, origin=lk)
        elif kind == "cancel":
            add(day, 11, chat, ME, "Please arrange the %s meeting" % t, key=lk)
            add(day, 12, chat, x, LANG["ack"][lang])
            if outcome == "dropped":
                add(day + R.randint(1, 4), 17, chat, ME, LANG["cancel"][lang].format(t=t), key=rk)
            row = dict(type="followup", owner=x, chat=chat, origin=lk)
        elif kind == "staff":
            who = R.choice(["u_ramu", "u_sanjay"])
            item = R.choice(["groceries", "tickets", "uniforms"])
            add(day, 9, "c_staff", ME, "%s, please get the %s" % (PEOPLE[who][0], item), key=lk)
            if outcome == "done":
                add(day + 1, 18, "c_staff", who, "%s aa gaye, %s sent" % (item, item), key=rk)
            row = dict(type="followup", owner=who, chat="c_staff", origin=lk)
            x = who
        elif kind == "question":
            add(day, 11, chat, x, "Should we approve the %s proposal?" % t, key=lk)
            if outcome == "done":
                add(day + 1, 14, chat, ME, "Yes, approve the %s proposal, go ahead" % t, key=rk)
            row = dict(type="question", owner=ME, chat=chat, origin=lk)
        else:
            add(day, 11, chat, x, "The payment for %s is due on %s" % (t, R.choice(DAYS)), key=lk)
            if outcome == "done":
                add(day + R.randint(1, 3), 16, chat, ME, "Payment done for %s, paid" % t, key=rk)
            row = dict(type="deadline", owner=ME, chat=chat, origin=lk)
        row.update(id=lk, status=outcome, resolution=rk if outcome in ("done", "dropped") else None, thing=t)
        if outcome == "open":
            if row["owner"] != ME:
                row["action"] = "leave"
            elif t in ("quotation", "proposal", "report", "estimate"):
                row["action"] = "assist"
            else:
                row["action"] = "remind"
        loops.append(row)
    ev.sort(key=lambda e: (e[0], e[1]))
    base = dt.datetime(2026, 1, 5, tzinfo=dt.timezone.utc)
    ids, rows = {}, []
    for n, (day, hour, chat, s, text, key, q) in enumerate(ev, 1):
        mid = "M%05d" % n
        if key:
            ids[key] = mid
        rows.append(dict(id=mid, chat_id=chat, sender_id=s, sender_name=PEOPLE[s][0] if s in PEOPLE else "Arjun",
                         ts=int((base + dt.timedelta(days=day, hours=hour)).timestamp()), kind="text", body=text, quoted_id=None))
    ddir, adir = os.path.join(out, "data"), os.path.join(out, "data", "answers")
    os.makedirs(adir, exist_ok=True)

    def jdump(path, obj):
        with open(path, "w", encoding="utf-8") as f:
            json.dump(obj, f, ensure_ascii=False, indent=1)

    with open(os.path.join(ddir, "messages.jsonl"), "w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    with open(os.path.join(ddir, "chats.jsonl"), "w", encoding="utf-8") as f:
        for cid, c in chats.items():
            f.write(json.dumps({"chat_id": cid, "name": c["name"], "is_group": c["group"], "participants": c["members"]}, ensure_ascii=False) + "\n")
    jdump(os.path.join(ddir, "seed.json"), {"circles": {p: v[1] for p, v in PEOPLE.items() if v[2]},
                                          "organisations": ["Arjun Textiles", "Home"], "goals": []})
    orgs = [{"id": "org_work", "name": "Arjun Textiles", "type": "company", "side": "work", "role": "owner"},
            {"id": "org_home", "name": "Home", "type": "residence", "side": "home", "role": "resident"},
            {"id": "org_society", "name": "Green Valley Society", "type": "society", "side": "home", "role": "resident"}]
    people = []
    for p, v in PEOPLE.items():
        e = {"id": p, "circle": v[1]}
        if v[1] in ("partner", "colleague"):
            e["links"] = [{"organisation": "org_work", "link": "runs" if v[1] == "partner" else "supports"}]
        if v[1] == "staff":
            e["links"] = [{"organisation": "org_home", "link": "supports"}]
        people.append(e)
    chat_rows = [{"chat_id": cid, ("organisation" if g[2].startswith("org_") else "person"): g[2]} for cid, g in groups.items()]
    chat_rows += [{"chat_id": "c_" + p, "person": p} for p in PEOPLE]
    answers = {
        "people": people, "organisations": orgs, "chats": chat_rows,
        "goals": [{"title": GOALS[i][0], "area": GOALS[i][1], "type": GOALS[i][2], "horizon": GOALS[i][3],
                   "evidence": [ids[k] for k in ks]} for i, ks in gkeys.items()],
        "open_loops": [{"title": l["thing"], "type": l["type"], "owner": l["owner"], "chat_id": l["chat"], "source_msgs": [ids[l["origin"]]],
                        "status": l["status"], "closing_msgs": [ids[l["resolution"]]] if l["resolution"] else [],
                        **({"help": l["action"], "why": ""} if l.get("action") else {})} for l in loops],
        "loops_scored_from": int((base + dt.timedelta(days=42)).timestamp()),
    }
    jdump(os.path.join(adir, "answers.json"), answers)
    print("chats=%d messages=%d loops=%d" % (len(chats), len(rows), len(loops)))


if __name__ == "__main__":
    main(sys.argv[1], int(sys.argv[2]) if len(sys.argv) > 2 else 1)
