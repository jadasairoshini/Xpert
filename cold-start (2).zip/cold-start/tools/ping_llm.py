"""Connection test: python tools/ping_llm.py  (reads .env). Prints success or the reason for failure. Never prints the key."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from src.config import Config, load_dotenv  # noqa: E402
from src.llm_client import LLMClient, LLMError  # noqa: E402

load_dotenv(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), ".env"))
cfg = Config.from_env()
cfg.max_retries = 1
try:
    cfg.validate()
except RuntimeError as e:
    sys.exit("Config problem: %s" % e)
print("Endpoint: %s | model: %s | key set: %s" % (cfg.base_url, cfg.model, bool(cfg.api_key)))
c = LLMClient(cfg, use_cache=False)
try:
    r = c.chat_json("Reply with JSON only.", 'Return {"ok": true, "word": "hello"}', max_tokens=200)
    print("SUCCESS:", r, "| usage:", c.usage())
except LLMError as e:
    sys.exit("FAILED: %s\nCheck: key valid? model name correct (list models in Google AI Studio)? quota/rate limit? internet/proxy?" % e)
