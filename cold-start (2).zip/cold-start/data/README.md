# Cold Start: the data

Unzip this inside the starter kit folder. It makes `data/dev/`. Then:

    ./run.sh data/dev out.json
    python3 check.py data/dev out.json

## What's here

`dev/` is the first two weeks of Arjun's WhatsApp: about 4,500 messages across 138 chats and
nearly 300 people. Arjun's own messages have the sender id `ME`.

Arjun is real, but these chats are not as he wrote them. We went through every message and changed
every name, company, specific place and number, and moved amounts. Big cities, public brands and
dates are as they were. Passwords and codes are removed. Please don't try to work out who it is
based on, don't share or commit this data, and delete it when the challenge ends.

## The answers

`dev/answers/answers.json` covers what we know for these two weeks:

- **Circles** for the people Arjun has placed himself. People he hasn't placed aren't scored.
- **Organisations** and which chats belong to them.
- **Open loops** found by our current system that were either done or still open at the end of
  the two weeks. They are good, not perfect: our system misses some and words others oddly. That is
  part of why we're running this challenge.
- **Goals** and **where to help** are not labelled in the dev set. The checker says so and leaves
  them out of the total. They are scored on the hidden set, which is labelled by hand.

`dev/seed.json` is what Arjun would tell a new assistant at signup: a few circles and two
organisation names.

## The hidden set

The six weeks after these, about 15,000 messages, with every name changed again so nothing carries
over from these answers. We run your code on it. Open loops are scored on its last two weeks.
